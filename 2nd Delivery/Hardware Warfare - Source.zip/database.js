const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost', // Same as 127.0.0.1
    user: 'root', // This could be different. Defined at installation!
    password: 'Cobaltosodio45@', // This is the root password of the DB
    database: 'hardware_warfare' // Schema name :)
});

module.exports = connection;